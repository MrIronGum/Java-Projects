package USACities;
import java.awt.Toolkit;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;
import javax.swing.*;
import static javax.swing.JFileChooser.APPROVE_OPTION;
import javax.swing.filechooser.FileNameExtensionFilter;
/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Class        CitiesGUI.java
 * Project      Large USA Cities Database
 * Description  A class representing the GUI used in a maintaining a cities 
 *              database obtained from a text file, Cities.txt with 5 fields:
 *              name, population in millions, median income, percent of native
 *              born, and percent of advanced degrees. Functionalities include:
 *              viewing of the data for selected city, add, delete, edit, sort
 *              by population and by name, and search for cpecified city.
 * File         CitiesGUI.java
 * Platform     jdk 1.8.0_214; NetBeans IDE 11.3; Windows 10
 * Course       CS 142, Edmonds Community College
 * Hours        12 hours and 45 minutes
 * Date         4/4/2020
 * History log  4/4/2011, 12/22/2018
 *
 * @author	<i>Abylay Dospayev</i>
 * @version 	%1% %2%
 * @see     	javax.swing.JFrame
 * @see        java.awt.Toolkit
 * @see         java.util.ArrayList
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
public class CitiesGUI extends JFrame
{    
    //class instance Arraylist of City objects
    private ArrayList<City> cities = new ArrayList<City>() ;
    //external file name for cities
    private String fileName = "src/USACities/Cities.txt";
    //private final String fileNameXML = "src/USACities/AltCities.xml"
    private DecimalFormat number = new DecimalFormat("#,##0");
    private DecimalFormat dollars = new DecimalFormat("$#,##0.00");
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * Constructor     CitiesGUI()-default constructor
     * Description     Create an instance of the CityGUI class
     * @author         <i>Abylay Dospayev</i>
     * Date            4/4/2020
     * History Log     7/18/2018, 12/13/2019
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/    
    public CitiesGUI()
    {
        initComponents();
        this.getRootPane().setDefaultButton(addJButton); //set addJButton as default
        this.setIconImage(Toolkit.getDefaultToolkit().
                getImage("src/USACities/buckinghamfountain_small.jpg"));
        //centers the form at start.
        setLocationRelativeTo(null);
        //Read form an external text file Cities.txt and populate 
        //the ArrayList of City type 
        readFromFile(fileName);
        
        //Show the member list in the JList and display data for selected city
        displayCities();
        int index = citiesJList.getSelectedIndex();
        if (index >= 0)
            showCityData(citiesJList.getSelectedIndex());
    }
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * Method       readFromFile
     * Description  Reads cities from a text file that is comma delimited and
     *              creates an instance of the City class with the data read.
     *              Then the newly created city is added to the cities database.
     *              Uses an object from the ReadFile class to read record.
     * @author      <i>Abylay Dospayev</i>
     * Date         4/4/2020
     * History Log  7/18/2018, 12/13/2019
     * @param       file  String
     * @see         java.util.Scanner  
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void readFromFile(String file)
    {
        cities.clear(); //clear the ArrayList 
        try
        {
           //File Reader inputFile = new FileReader(file);
           //BufferReader input = new BufferedReader(input file)
           //Read while there's data
           Scanner input = new Scanner(new File(file)); //alternative to FileReader & BufferedReader
          
           String line = "";
           City metropolis = null;
           StringTokenizer token = null;
           while(input.hasNextLine())
           {
               line = input.nextLine();
               metropolis = new City();
               token = new StringTokenizer(line, ",");
               while (token.hasMoreElements())
               {
                    metropolis.setName(token.nextToken());
                    metropolis.setPopulation(Float.parseFloat(token.nextToken()));
                    metropolis.setMedian(Float.parseFloat(token.nextToken()));
                    metropolis.setLocal(Float.parseFloat(token.nextToken()));
                    metropolis.setDegree(Float.parseFloat(token.nextToken()));
               
               }
               //add city to arrayList
               cities.add(metropolis);
           }
           input.close();
        }

        
        
        catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, file + " does not exist",
                    "File input Error", JOptionPane.WARNING_MESSAGE);
            //Bring up JFileChooser to select file in current directory
            JFileChooser chooser = new JFileChooser("src/USACities");
            //Filter only txt files 
            FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "Txt Files", "txt");
            chooser.setFileFilter(filter);
            int choice = chooser.showOpenDialog(null);
            if (choice == JFileChooser.APPROVE_OPTION)
            {
                File chosenFile = chooser .getSelectedFile();
                file = "src/USACities/" + chosenFile.getName();
                System.out.println("file = " + file);
                readFromFile(file);
            }
            else // I/O error
            {
                JOptionPane.showMessageDialog(null, "Unable to read file",
                        "File Input Error", JOptionPane.WARNING_MESSAGE);
            }
        }
        //catch(IOException e)
        //{
          //  JOptionPane.showMessageDialog(null, "Unable to read file", 
            //        "File Input Error", JOptionPane.WARNING_MESSAGE);
            //System.exit(0);
        //}
    }

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>>
     * Method       displaycities()
     * Description  Displays cities in JList sorted by level = 0 using 
     *              selection sort algorithm or last name = 1 using the 
     *              insertion sort algorithm.
     * @author      <i>Abylay Dospayev</i>
     * Date         9/28/2022
     * History Log  
     * @see         #selectionSort
     * @see         #insetionSort
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @SuppressWarnings("unchecked")
     private void displayCities()
     {
         int location = citiesJList.getSelectedIndex();    //get index of current city
         String[] citiesList = new String[cities.size()];
         if (popJRadioButtonMenuItem.isSelected())
         {
             //sort by size using selection sort in descending order and display name and population
             //sort by population using quick sort in descending order and display name and population
             selectionSort(cities);
             //quickSort(cities);
             for(int index = 0; index < cities.size(); index++)
             {
                 citiesList[index] = cities.get(index).getName()+", "
                         + cities.get(index).getPopulation()+"mil.";
             }
             
         }
         else //display cities by name only
         {
             //sort by city name using insertion sort and display name only
             insertionSort(cities);
             //sort by city name using merge sort and display name only
             //mergeSort(cities);
             for(int index = 0; index < cities.size(); index++)
             {
                 citiesList[index] = cities.get(index).getName();
             }
         }
         citiesJList.setListData(citiesList); //populate JList with citielist
         if(location < 0)
             citiesJList.setSelectedIndex(0);   //select first city
         else 
             citiesJList.setSelectedIndex(location);
             
     }
     /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>>
     * Method       showCityData()
     * Description  Display information about selected city 
     * @param       index int 
     * @author      <i>Abylay Dospayev</i>
     * Date         9/28/2020
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
     private void showCityData(int index)
     {
        if (index >= 0 && index < cities.size())
        {
            nameJTextField.setText(cities.get(index).getName());
            popJTextField.setText(String.valueOf(cities.get(index).getPopulation()));
            medianJTextField.setText("$" + number.format(cities.get(index).getMedian()));
            percentJTextField.setText(number.format(cities.get(index).getLocal()) + "%");
            degreeJTextField.setText(number.format(cities.get(index).getDegree())+"%");
        }
     }
     
     
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * Method       insertionSort
     * Description  Sorts ArrayList cities in ascending order by name. Uses 
     *              the insertion sort algorithm which inserts city at correct 
     *              position and shuffles everyone else below that position.
     * @param       cities ArrayList
     * @author      <i>Abylay Dospayev</i>
     * Date         4/4/2020
     * History Log  7/18/2018, 12/13/2019
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
     public static void insertionSort(ArrayList<City> cities)
     {
         int i,j;
         for (i = 0; i < cities.size(); i++)
         {
             City temp = cities.get(i);
             j = i - 1;
             while (j >= 0 && cities.get(j).getName().compareToIgnoreCase(temp.getName())>0)
             {
                 cities.set(j+1, cities.get(j));
                 j--;
             }
             cities.set(j+1, temp);
         }
     }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * Method       selectionSort
     * Description  Sorts ArrayList cities in descending order by population. 
     *              Calls findsMaximum to find city with maximum population in 
     *              each pass and swap to exchange cities when necessary.
     * @param       cities ArrayList
     * @author      <i>Niko Culevski</i>
     * Date         4/4/2020
     * History Log  7/18/2018, 12/13/2019
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/             
     public void selectionSort(ArrayList<City> cities)
     {
         int max = 0;
         for (int i=0; i < cities.size(); i++)
         {
             max = findMaximum(cities, i);
             //swap(cities, i, max)
             City temp = cities.get(i);
             cities.set(i, cities.get(max));
             cities.set(max,temp);
         }
     }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     *<pre>>
     * Method       findMaximum
     * Description  Called by selectionSort to find the index of the member 
     *              with the maximum population from a given index to the end 
     *              of the ArrayList
     * @param       cities ArrayList
     * @param       i Integer
     * @author      <i>Abylay Dospayev</i>
     * @return      max
     * Date         4/4/2020
     * History Log  7/18/2018, 12/13/2019
     * </pre>
     *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
     public int findMaximum(ArrayList< City > cities, int i)
     {
         int j, max = i;
         for (j= i + 1; j < cities.size(); j++)
         {
             if (cities.get(j).getPopulation() > cities.get(max).getPopulation())
                 max = j;
         }
         return max;
     }
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sortButtonGroup = new javax.swing.ButtonGroup();
        titleJPanel = new javax.swing.JPanel();
        logoJLabel = new javax.swing.JLabel();
        titleJLabel = new javax.swing.JLabel();
        listJPanel = new javax.swing.JPanel();
        llistJScrollPane = new javax.swing.JScrollPane();
        citiesJList = new javax.swing.JList();
        displayJPanel = new javax.swing.JPanel();
        nameJLabel = new javax.swing.JLabel();
        nameJTextField = new javax.swing.JTextField();
        popJLabel = new javax.swing.JLabel();
        popJTextField = new javax.swing.JTextField();
        medianJLabel = new javax.swing.JLabel();
        medianJTextField = new javax.swing.JTextField();
        percentJLabel = new javax.swing.JLabel();
        percentJTextField = new javax.swing.JTextField();
        degreetJLabel = new javax.swing.JLabel();
        degreeJTextField = new javax.swing.JTextField();
        controlPanel = new javax.swing.JPanel();
        addJButton = new javax.swing.JButton();
        editJButton = new javax.swing.JButton();
        deleteJButton = new javax.swing.JButton();
        printJButton = new javax.swing.JButton();
        exitJButton = new javax.swing.JButton();
        citiesJMenuBar = new javax.swing.JMenuBar();
        fileJMenu = new javax.swing.JMenu();
        newJMenuItem = new javax.swing.JMenuItem();
        printJMenuItem = new javax.swing.JMenuItem();
        printCityJMenuItem1 = new javax.swing.JMenuItem();
        fileJSeparator = new javax.swing.JPopupMenu.Separator();
        exitJMenuItem = new javax.swing.JMenuItem();
        sortJMenu = new javax.swing.JMenu();
        nameJRadioButtonMenuItem = new javax.swing.JRadioButtonMenuItem();
        popJRadioButtonMenuItem = new javax.swing.JRadioButtonMenuItem();
        actionJMendatabaseJMenuu = new javax.swing.JMenu();
        addJMenuItem = new javax.swing.JMenuItem();
        deleteJMenuItem = new javax.swing.JMenuItem();
        editJMenuItem = new javax.swing.JMenuItem();
        searchJMenuItem = new javax.swing.JMenuItem();
        helpJMenu = new javax.swing.JMenu();
        aboutJMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Large USA Cities Statistics");
        setResizable(false);

        logoJLabel.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        logoJLabel.setForeground(new java.awt.Color(51, 0, 0));
        logoJLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/USACities/buckinghamfountain.jpg"))); // NOI18N

        titleJLabel.setFont(new java.awt.Font("Tempus Sans ITC", 2, 24)); // NOI18N
        titleJLabel.setForeground(new java.awt.Color(51, 0, 0));
        titleJLabel.setText("Large Cities in USA");

        javax.swing.GroupLayout titleJPanelLayout = new javax.swing.GroupLayout(titleJPanel);
        titleJPanel.setLayout(titleJPanelLayout);
        titleJPanelLayout.setHorizontalGroup(
            titleJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titleJPanelLayout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(logoJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(titleJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );
        titleJPanelLayout.setVerticalGroup(
            titleJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, titleJPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(titleJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(logoJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, Short.MAX_VALUE)
                    .addComponent(titleJLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE))
                .addContainerGap())
        );

        getContentPane().add(titleJPanel, java.awt.BorderLayout.NORTH);

        citiesJList.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        citiesJList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                citiesJListValueChanged(evt);
            }
        });
        llistJScrollPane.setViewportView(citiesJList);

        javax.swing.GroupLayout listJPanelLayout = new javax.swing.GroupLayout(listJPanel);
        listJPanel.setLayout(listJPanelLayout);
        listJPanelLayout.setHorizontalGroup(
            listJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, listJPanelLayout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(llistJScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        listJPanelLayout.setVerticalGroup(
            listJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(llistJScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE)
        );

        getContentPane().add(listJPanel, java.awt.BorderLayout.LINE_START);

        displayJPanel.setLayout(new java.awt.GridLayout(5, 2, 5, 5));

        nameJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        nameJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        nameJLabel.setText("Name of city: ");
        displayJPanel.add(nameJLabel);

        nameJTextField.setEditable(false);
        nameJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        displayJPanel.add(nameJTextField);

        popJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        popJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        popJLabel.setText("Population (in millions): ");
        displayJPanel.add(popJLabel);

        popJTextField.setEditable(false);
        popJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        popJTextField.setToolTipText("Press Enter to update");
        displayJPanel.add(popJTextField);

        medianJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        medianJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        medianJLabel.setText("Median income (per household): ");
        displayJPanel.add(medianJLabel);

        medianJTextField.setEditable(false);
        medianJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        medianJTextField.setToolTipText("Enter with no $ or commas and press Enter to update");
        displayJPanel.add(medianJTextField);

        percentJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        percentJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        percentJLabel.setText("Percent native to state: ");
        displayJPanel.add(percentJLabel);

        percentJTextField.setEditable(false);
        percentJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        percentJTextField.setToolTipText("Enter without % sign and pres Enter to update");
        percentJTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                percentJTextFieldActionPerformed(evt);
            }
        });
        displayJPanel.add(percentJTextField);

        degreetJLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        degreetJLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        degreetJLabel.setText("Percent advanced degrees: ");
        displayJPanel.add(degreetJLabel);

        degreeJTextField.setEditable(false);
        degreeJTextField.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        degreeJTextField.setToolTipText("Enter without % sign and press Enter to update");
        displayJPanel.add(degreeJTextField);

        getContentPane().add(displayJPanel, java.awt.BorderLayout.CENTER);

        controlPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        controlPanel.setMinimumSize(new java.awt.Dimension(299, 45));
        controlPanel.setLayout(new java.awt.GridLayout(1, 5, 5, 5));

        addJButton.setBackground(new java.awt.Color(204, 255, 204));
        addJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        addJButton.setMnemonic('A');
        addJButton.setText("Add");
        addJButton.setToolTipText("Add new city");
        addJButton.setMinimumSize(new java.awt.Dimension(57, 45));
        addJButton.setPreferredSize(new java.awt.Dimension(57, 35));
        addJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addJButtonActionPerformed(evt);
            }
        });
        controlPanel.add(addJButton);

        editJButton.setBackground(new java.awt.Color(204, 255, 204));
        editJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        editJButton.setMnemonic('E');
        editJButton.setText("Edit");
        editJButton.setToolTipText("Edit city. Press Enter in any of the JTextFields to confirm changes...");
        editJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editJButtonActionPerformed(evt);
            }
        });
        controlPanel.add(editJButton);

        deleteJButton.setBackground(new java.awt.Color(204, 255, 204));
        deleteJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        deleteJButton.setMnemonic('D');
        deleteJButton.setText("Delete");
        deleteJButton.setToolTipText("Delete city");
        deleteJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteJButtonActionPerformed(evt);
            }
        });
        controlPanel.add(deleteJButton);

        printJButton.setBackground(new java.awt.Color(204, 255, 204));
        printJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        printJButton.setMnemonic('P');
        printJButton.setText("Print");
        printJButton.setToolTipText("Print individual city data");
        printJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printJButtonActionPerformed(evt);
            }
        });
        controlPanel.add(printJButton);

        exitJButton.setBackground(new java.awt.Color(204, 255, 204));
        exitJButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        exitJButton.setMnemonic('x');
        exitJButton.setText("Exit");
        exitJButton.setToolTipText("Exit application");
        exitJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitJButtonActionPerformed(evt);
            }
        });
        controlPanel.add(exitJButton);

        getContentPane().add(controlPanel, java.awt.BorderLayout.SOUTH);

        fileJMenu.setMnemonic('F');
        fileJMenu.setText("File");

        newJMenuItem.setMnemonic('N');
        newJMenuItem.setText("New");
        newJMenuItem.setToolTipText("New City DB");
        newJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(newJMenuItem);

        printJMenuItem.setMnemonic('P');
        printJMenuItem.setText("Print Form");
        printJMenuItem.setToolTipText("Print form as GUI");
        printJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(printJMenuItem);

        printCityJMenuItem1.setMnemonic('y');
        printCityJMenuItem1.setText("Print City");
        printCityJMenuItem1.setToolTipText("Print city data");
        printCityJMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printCityJMenuItem1ActionPerformed(evt);
            }
        });
        fileJMenu.add(printCityJMenuItem1);
        fileJMenu.add(fileJSeparator);

        exitJMenuItem.setMnemonic('x');
        exitJMenuItem.setText("Exit");
        exitJMenuItem.setToolTipText("");
        exitJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitJMenuItemActionPerformed(evt);
            }
        });
        fileJMenu.add(exitJMenuItem);

        citiesJMenuBar.add(fileJMenu);

        sortJMenu.setMnemonic('S');
        sortJMenu.setText("Sort");

        sortButtonGroup.add(nameJRadioButtonMenuItem);
        nameJRadioButtonMenuItem.setMnemonic('n');
        nameJRadioButtonMenuItem.setSelected(true);
        nameJRadioButtonMenuItem.setText("By Name");
        nameJRadioButtonMenuItem.setToolTipText("Sort by name and display only name");
        nameJRadioButtonMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameJRadioButtonMenuItemActionPerformed(evt);
            }
        });
        sortJMenu.add(nameJRadioButtonMenuItem);

        sortButtonGroup.add(popJRadioButtonMenuItem);
        popJRadioButtonMenuItem.setMnemonic('B');
        popJRadioButtonMenuItem.setText("By Population");
        popJRadioButtonMenuItem.setToolTipText("Sort by populatoin a nd display name and population");
        popJRadioButtonMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                popJRadioButtonMenuItemActionPerformed(evt);
            }
        });
        sortJMenu.add(popJRadioButtonMenuItem);

        citiesJMenuBar.add(sortJMenu);

        actionJMendatabaseJMenuu.setMnemonic('t');
        actionJMendatabaseJMenuu.setText("DataBase Management");

        addJMenuItem.setMnemonic('A');
        addJMenuItem.setText("Add New City");
        addJMenuItem.setToolTipText("Add new city");
        addJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addJMenuItemActionPerformed(evt);
            }
        });
        actionJMendatabaseJMenuu.add(addJMenuItem);

        deleteJMenuItem.setMnemonic('D');
        deleteJMenuItem.setText("Delete City");
        deleteJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteJMenuItemActionPerformed(evt);
            }
        });
        actionJMendatabaseJMenuu.add(deleteJMenuItem);

        editJMenuItem.setMnemonic('E');
        editJMenuItem.setText("Edit City");
        editJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editJMenuItemActionPerformed(evt);
            }
        });
        actionJMendatabaseJMenuu.add(editJMenuItem);

        searchJMenuItem.setMnemonic('r');
        searchJMenuItem.setText("Search City");
        searchJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchJMenuItemActionPerformed(evt);
            }
        });
        actionJMendatabaseJMenuu.add(searchJMenuItem);

        citiesJMenuBar.add(actionJMendatabaseJMenuu);

        helpJMenu.setMnemonic('H');
        helpJMenu.setText("Help");

        aboutJMenuItem.setMnemonic('A');
        aboutJMenuItem.setText("About");
        aboutJMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutJMenuItemActionPerformed(evt);
            }
        });
        helpJMenu.add(aboutJMenuItem);

        citiesJMenuBar.add(helpJMenu);

        setJMenuBar(citiesJMenuBar);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        exitJButtonActionPerformed()
    * Description   Event handler to close the application
    * @param        evt ActionWvent
    * @see          java.awt.event.ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          4/4/2020
    * History Log   7/18/2018, 12/13/2019
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void exitJButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_exitJButtonActionPerformed
    {//GEN-HEADEREND:event_exitJButtonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitJButtonActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        exitJMenuItemActionPerformed()
    * Description   Call the exitJButtonActionPerformed event handler to exit
    * @param        evt ActionWvent
    * @see          java.awt.event.ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          4/4/2020
    * History Log   7/18/2018, 12/13/2019   
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void exitJMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_exitJMenuItemActionPerformed
    {//GEN-HEADEREND:event_exitJMenuItemActionPerformed
        exitJButtonActionPerformed(evt);
    }//GEN-LAST:event_exitJMenuItemActionPerformed

 /**
 * <pre>
 * Method       citiesjList1ValueChanged
 * Description  Event handler for citiesJListValueChanged to update
 *              information on selected city
 * @parem       evt ListSelectionEvent
 * @author      Abylay Dospayev
 * Date         9/24/2022
 * </pre> 
 */
    private void citiesJListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_citiesJListValueChanged
        int index = (citiesJList.getSelectedIndex());
        if (index >= 0)
            showCityData(index);
    }//GEN-LAST:event_citiesJListValueChanged
    /**
 * <pre>
 * Method       cityExists()
 * Description  Boolean method to determine if a city to be added exists
 * @return      thereIsOne
 * @param       metropolis city
 * @author      Abylay Dospayev
 * Date         9/24/2022
 * </pre> 
 */
    private boolean cityExists(City metropolis){
        boolean thereIsOne = false;
        for(int index = 0; index < cities.size() && !thereIsOne; index++){
            if(cities.get(index).equals(metropolis))
                thereIsOne = true;
        }
        return thereIsOne;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        newJMenuItemActionPerformed()
    * Description   Show a JFileChooser with an OpenDialog to detect a
    *               different cities database
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void newJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newJMenuItemActionPerformed
        JFileChooser chooser = new JFileChooser("src\\USACities");
        // Filter only txt files
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Txt Files", "txt");
        chooser.setFileFilter(filter);
        int choice = chooser.showOpenDialog(null);
        if (choice == JFileChooser.APPROVE_OPTION)
        {
            //Clear existing cities ArrayList and JList 
            cities.clear();
            citiesJList.removeAll();
            File chosenFile = chooser.getSelectedFile();
            String file = "src/USACities/" + chosenFile.getName();
            
            //need to update fileName to save changes in correct file--cannot be final 
            fileName = file;

            readFromFile(file);
            displayCities();
        }
        else //weird error
        {
            JOptionPane.showMessageDialog(null, "Unable to read file",
                    "File Input Error", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_newJMenuItemActionPerformed

    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        nameJRadioButtonMenuItemActionPerformed()
    * Description   Event Handler for nameJRadioButtonMenuItem to display 
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void nameJRadioButtonMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameJRadioButtonMenuItemActionPerformed
        // display cities sorted by last name
        displayCities();
    }//GEN-LAST:event_nameJRadioButtonMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        popJRadioButtonMenuItemActionPerformed()
    * Description   Event Handler for nameJRadioButtonMenuItem to display 
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void popJRadioButtonMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_popJRadioButtonMenuItemActionPerformed
        // display cities sorted by population
        displayCities();
    }//GEN-LAST:event_popJRadioButtonMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        printJMenuItemActionPerformed()
    * Description   Event Handler for printJMenuItem to print the form as a GUI
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void printJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printJMenuItemActionPerformed
       PrintUtilities.printComponent(this);      
    }//GEN-LAST:event_printJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        printJMenuItem1ActionPerformed()
    * Description   Event Handler for deleteButton to delete selected city
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    
    private void printCityJMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printCityJMenuItem1ActionPerformed
        // Print selected city
        printJButtonActionPerformed(evt);
    }//GEN-LAST:event_printCityJMenuItem1ActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        aboutJMenuItemActionPerformed()
    * Description   Event Handler for aboutJMenuItemActionPerformed to show About form
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    private void aboutJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutJMenuItemActionPerformed
        //Display About form
        About aboutWindow = new About(this, true);
        aboutWindow.setVisible(true);
    }//GEN-LAST:event_aboutJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        deleteJButtonActionPerformed()
    * Description   Event Handler for deleteJButton to delete selcted city
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void deleteJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteJButtonActionPerformed
        int index = citiesJList.getSelectedIndex();
        String name = cities.get(index).getName();
        int result = JOptionPane.showConfirmDialog(null, 
                "Are you sure you wish to delete " + name + "?", "Delete city",
                JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
        
        if (result == JOptionPane.YES_OPTION)   //confirm delete selected city
        {
            index = citiesJList.getSelectedIndex();
            cities.remove(index);
            displayCities();
            saveCities(fileName);
        }
    }//GEN-LAST:event_deleteJButtonActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        deleteJMenuItemActionPerformed
    * Description   Event Handler for addMenuItem to invoke to deleteJMenuItem
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void deleteJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteJMenuItemActionPerformed
       deleteJButtonActionPerformed(evt);
       
    }//GEN-LAST:event_deleteJMenuItemActionPerformed

     /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        searchJMenuItemActionPerformed
    * Description   Event Handler for searchJMenuItem
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void searchJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchJMenuItemActionPerformed
        //Find specified city
        String cityName = JOptionPane.showInputDialog("Enter name of city");
        searchCity(cityName);
    }//GEN-LAST:event_searchJMenuItemActionPerformed

    private void percentJTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_percentJTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_percentJTextFieldActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        printJButtonActionPerformed()
    * Description   Event Handler to print details of selected city
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void printJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printJButtonActionPerformed
        int index = citiesJList.getSelectedIndex();
        JTextArea printCity = new JTextArea();
        if(index >= 0)
        {
            try 
            {
                City temp = new City(cities.get(index));
                String output = "City: " + temp.getName() + "\n" + 
                        "Population: " + temp.getPopulation() + " million\n" +
                        "Median Income: " + dollars.format(temp.getMedian())+"\n" +
                        "Percent of Local Population: " + temp.getLocal() + "%\n" +
                        "Percent of Advanced Degree: " + temp.getDegree() + "%\n";
               printCity.setText(output);
               printCity.print();
            }
            catch(PrinterException ex)
            {
                JOptionPane.showMessageDialog(null, "City not Printed",
                        "Print Error", JOptionPane.WARNING_MESSAGE);
            }
        }
    }//GEN-LAST:event_printJButtonActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        addJButtonActionPerformed()
    * Description   Event Handler for adding a city by invoking the AddCity
    *               form.No empty or duplicate city is added.The new city 
    *               is added to the JList and saved in the Cities.txt file
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void addJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addJButtonActionPerformed
        try
        {
            //Create and display a new AddDialog
            AddCity addCity = new AddCity(this, true);
            addCity.setVisible(true);//the modal dialog takes focus, upon regainig focus:
            City newCity;
            newCity = addCity.getCity();
            if(newCity != null && !cityExists(newCity))
            {
                //Add the new city to database
                cities.add(addCity.getCity());
                displayCities();
                searchCity(newCity.getName());
                
                //save new city to file
                saveCities(fileName);
            }
            else
            {
                citiesJList.setVisible(true);
                citiesJList.setSelectedIndex(0);
            }
        }
        catch (NullPointerException nullex)
        {
            JOptionPane.showMessageDialog(null, "City not Added", 
                    "Added City Error", JOptionPane.WARNING_MESSAGE);
            citiesJList.setVisible(true);
            citiesJList.setSelectedIndex(0);
            
         
        }
    }//GEN-LAST:event_addJButtonActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        editJButtonActionPerformed()
    * Description   Event Handler for editJButtonActionPerformed to edit city
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void editJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editJButtonActionPerformed
        try
        {
            String cityName = citiesJList.getSelectedValue().toString();
            if(cityName.contains(","))
        
                cityName= cityName.substring(0, cityName.indexOf(','));
            City cityToEdit = new City(findCity(cityName));
            int index = citiesJList.getSelectedIndex();
            EditCity editedCity = new EditCity(cityToEdit);
            editedCity.setVisible(true);
            if (editedCity.getCity() != null)
            {
                cities.remove(index);
                cities.add(editedCity.getCity());
                saveCities(fileName);
                displayCities();
            }
        }
        
        catch(NullPointerException nullex)
        {
            JOptionPane.showMessageDialog(null,"City not Edited","Edit City Error", 
                    JOptionPane.WARNING_MESSAGE);
            citiesJList.setVisible(true);
            citiesJList.setSelectedIndex(0);
        }
    }//GEN-LAST:event_editJButtonActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        addJMenuItemActionPerformed()
    * Description   Event Handler for addJMenuItem to invoke the 
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void addJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addJMenuItemActionPerformed
        addJButtonActionPerformed(evt);
    }//GEN-LAST:event_addJMenuItemActionPerformed
/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        editJMenuItemActionPerformed()
    * Description   Event Handler for editJButtonActionPerformed to edit city
    * @param        evt ActionEvent
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void editJMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editJMenuItemActionPerformed
       editJButton.doClick();
    }//GEN-LAST:event_editJMenuItemActionPerformed
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        findCity()
    * Description   Search for a city by name and highlight if found 
    * @param        cityName String
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private City findCity(String cityName)
    {
        int index = -1;
        nameJRadioButtonMenuItem.doClick();
        for (int i = 0; i < cities.size(); i++)
        {
            if (cityName.equals(cities.get(i).getName()))
                index = i;
        }
        if (index >= 0 )
        {
            citiesJList.setSelectedIndex(index);
            return cities.get(index);
        }
        else
            return null;
    }
        
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        searchCity
    * Description   Search for a city by name and highlight if found 
    * @param        cityName String
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void searchCity(String cityName)
    {
        if ((cityName != null) && (cityName.length()>0))
        {
            //Sort the JList of city name by name 
            nameJRadioButtonMenuItem.setSelected(true);
            displayCities();
            
            //Create a String array of city names
            String[] cityArray = new String[cities.size()];
            for (int i = 0; i < cityArray.length; i++)
                cityArray[i] = cities.get(i).getName().toLowerCase();
            //Find index of city
            //int index = binarySearch(cityArray, cityName.toLowerCase());
            int index = linearSearch(cityArray, cityName.toLowerCase());
            if (index < 0)
            {
                JOptionPane.showMessageDialog(null, "City" + cityName + 
                        " not Found", "Search Result", JOptionPane.WARNING_MESSAGE);
                citiesJList.setSelectedIndex(0);
            }
            else 
                citiesJList.setSelectedIndex(index);
        }
    }
    
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        linearSearch()
    * Description   Event handler to search city by name using the linear 
    *               search algorithm and to display its index if found and -1 if not found
    * @return       index int
    * @param        cityArray String[]
    * @param        cityName String
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private int linearSearch(String[] cityArray, String cityName)
    {
        int index = -1;
        boolean found = false;
        for (int i = 0; i < cityArray.length && !found; i++)
        {
            if(cityArray[i].toLowerCase().contains(cityName.toLowerCase()))
            {
                index = i;
                found = true;
            }
        }
        return index;
    }
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        binarySearch()
    * Description   Seacrh by city name using the binary search method
    *               Returns -1 if city is not found 
    * @param        array String[]
    * @param        key String
    * @return       middle int, index of where city is found
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public static int binarySearch(String[] array, String key)
    {
        int low = 0;                    //low subscript
        int high = array.length - 1;    //high subscript
        int middle;                     //middle subscript
        
        while (low <= high)
        {
            middle = ( low + high ) / 2;
            if (key.equalsIgnoreCase(array[middle]))    //exact match
            //if (array[middle].contains(key))  //partial match doesn't work
                return middle;
            else if (key.compareToIgnoreCase(array[middle])<0)
                high = middle - 1;  //search low end of array
            else 
                low = middle + 1;   //search high end of array
        }
        
        return -1;  //searchKey not found
    }
    
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        saveCities()
    * Description   Write cities to a text file that is comma delimited
    * @param        file String
    * @author       <i>Abylay Dospayev</i>
    * Date          9/28/2022
    * History Log      
    * @see          java.io.FileWriter
    * @see          java.io.PrintWrite
    * @see          City
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private void saveCities(String file)
    {
        
        try 
        {
            FileWriter filePointer = new FileWriter(file, false);
            PrintWriter output = new PrintWriter(filePointer);
            for(int index = 0; index < cities.size(); index++)
            {
                City tempCity = cities.get(index);
                String line = tempCity.getName() + "," + 
                        tempCity.getPopulation()+ "," + tempCity.getMedian() +
                        "," + tempCity.getLocal() + "," + tempCity.getDegree();
            // do not add an extra blank line to end of file
            if (index == cities.size()-1)
                output.write(line);
            else 
                output.write(line + "\n");
            }
            output.close();
        }
        catch(IOException ex)
        {
            JOptionPane.showMessageDialog(null, "City not Saved", "Save Error",
                    JOptionPane.WARNING_MESSAGE);
            citiesJList.setVisible(true);
            citiesJList.setSelectedIndex(0);
        }
    }
    
    
    /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    *<pre>
    * Method        main()
    * Description   Call the contructor to create an instance of the form
    * @param        args are the command line strings
    * @author       <i>Abylay Dospayev</i>
    * Date          4/4/2020
    * History Log   7/18/2018, 12/13/2019     
    *</pre>
    *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/ 
    
    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        Splash mySplash = new Splash(2500);
        mySplash.showSplash();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                new CitiesGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem aboutJMenuItem;
    private javax.swing.JMenu actionJMendatabaseJMenuu;
    private javax.swing.JButton addJButton;
    private javax.swing.JMenuItem addJMenuItem;
    private javax.swing.JList citiesJList;
    private javax.swing.JMenuBar citiesJMenuBar;
    private javax.swing.JPanel controlPanel;
    private javax.swing.JTextField degreeJTextField;
    private javax.swing.JLabel degreetJLabel;
    private javax.swing.JButton deleteJButton;
    private javax.swing.JMenuItem deleteJMenuItem;
    private javax.swing.JPanel displayJPanel;
    private javax.swing.JButton editJButton;
    private javax.swing.JMenuItem editJMenuItem;
    private javax.swing.JButton exitJButton;
    private javax.swing.JMenuItem exitJMenuItem;
    private javax.swing.JMenu fileJMenu;
    private javax.swing.JPopupMenu.Separator fileJSeparator;
    private javax.swing.JMenu helpJMenu;
    private javax.swing.JPanel listJPanel;
    private javax.swing.JScrollPane llistJScrollPane;
    private javax.swing.JLabel logoJLabel;
    private javax.swing.JLabel medianJLabel;
    private javax.swing.JTextField medianJTextField;
    private javax.swing.JLabel nameJLabel;
    private javax.swing.JRadioButtonMenuItem nameJRadioButtonMenuItem;
    private javax.swing.JTextField nameJTextField;
    private javax.swing.JMenuItem newJMenuItem;
    private javax.swing.JLabel percentJLabel;
    private javax.swing.JTextField percentJTextField;
    private javax.swing.JLabel popJLabel;
    private javax.swing.JRadioButtonMenuItem popJRadioButtonMenuItem;
    private javax.swing.JTextField popJTextField;
    private javax.swing.JMenuItem printCityJMenuItem1;
    private javax.swing.JButton printJButton;
    private javax.swing.JMenuItem printJMenuItem;
    private javax.swing.JMenuItem searchJMenuItem;
    private javax.swing.ButtonGroup sortButtonGroup;
    private javax.swing.JMenu sortJMenu;
    private javax.swing.JLabel titleJLabel;
    private javax.swing.JPanel titleJPanel;
    // End of variables declaration//GEN-END:variables


}
