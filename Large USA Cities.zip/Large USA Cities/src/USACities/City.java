package USACities;
/**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼  
 * File name     City.Java
 * Description   A class representing a large USA city with 5 properties; name, 
 *               population (in millions), median income, present native born, 
 *               and percent with advanced degree
 * Project       Large USA Cities Database
 * Platform      jdk 1.8.0_51-b16, NetBeans IDE 15 Windows 10
 * Course        CS 142
 * Hours         1 hours and 20 minutes
 * Date          9/23/2022
 * @author       <i>Abylay Dospayev</i>
 * @version     1.0.0
∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
public class City 
{
    //instance variables
    private String name;
    private float population;
    private float median;
    private float local;
    private float degree;
    
    
    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Constructor     City() - default constructor
    *   Description     Create an instance of the City class and assigns 
    *                   default values to all fields
    *   @author         <i>Abylay Dospayev</i>
    *   Date            9/23/2022  
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    public City()
    {
        name = "";
        population = 0;
        median = 0;
        local = 0;
        degree = 0;
    }
    
    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Constructor     City() - default constructor
    *   Description     Create an instance of the City class and assigns 
    *                   default values via parameteres to all fields
    *   @author         <i>Abylay Dospayev</i>
    *   @param          city String
    *   @param          pop float
    *   @param          median float
    *   @param          nat float 
    *   @param          degree float
    * 
    *   Date            9/23/2022 
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/ 
    public City(String city, float pop, float median, float nat, float degree)
    {
        name = city; 
        population = pop;
        this.median = median; 
        local = nat; 
        this.degree = degree;
    }
    
     /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Constructor     City() - default constructor
    *   Description     Create an instance of the City class and assigns 
    *                   default values via parameteres to all fields
    *   @author         <i>Abylay Dospayev</i>
    *   @param          anotherCity City
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/ 
    
    public City(City anotherCity)
    {
       name = anotherCity.name;
       population = anotherCity.population;
       this.median = anotherCity.median;
       local = anotherCity.local;
       this.degree = anotherCity.degree;
    }

    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          getName()
    *   Description     Get method to return instance variable name.
    *   @author         <i>Abylay Dospayev</i>
    *   @return         name String
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/ 
    public String getName()
    {
        return name;
    }

    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          setName()
    *   Description     Set method to set instance variable name
    *   @author         <i>Abylay Dospayev</i>
    *   @param          name String
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/ 
    public void setName(String name) 
    {
        this.name = name;
    }

    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          getPopulation()
    *   Description     Get method to return instance variable population.
    *   @author         <i>Abylay Dospayev</i>
    *   @return         population float
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    public float getPopulation() 
    {
        return population;
    }

    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          setPopulation()
    *   Description     Set method to set instance variable population.
    *   @author         <i>Abylay Dospayev</i>
    *   @param          population float
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    public void setPopulation(float population)
    {
        this.population = population;
    }

    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          getMedian()
    *   Description     Get method to return instance variable median
    *   @author         <i>Abylay Dospayev</i>
    *   @return         median float
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    public float getMedian() 
    {
        return median;
    }

    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          setMedian(float median)
    *   Description     Set method to set instance variable name
    *   @author         <i>Abylay Dospayev</i>
    *   @param          median float
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    public void setMedian(float median)
    {
        this.median = median;
    }
    
    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    *   Method          getLocal()
    *   Description     Get method to return instance variable local.
    *   @author         <i>Abylay Dospayev</i>
    *   @return         population float
    *   Date            9/23/2022
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    public float getLocal()
    {
        return local;
    }

    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          setLocal()
    *   Description     Set method to set instance variable local.
    *   @author         <i>Abylay Dospayev</i>
    *   @param          local float
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    public void setLocal(float local) 
    {
        this.local = local;
    }

    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          getDegree()
    *   Description     Set method to return instance variable degree.
    *   @author         <i>Abylay Dospayev</i>
    *   @return         degree float
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    public float getDegree() 
    {
        return degree;
    }
    
    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          setDegree()
    *   Description     Set method to set instance variable degree.
    *   @author         <i>Abylay Dospayev</i>
    *   @param         degree float
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    public void setDegree(float degree) 
    {
        this.degree = degree;
    }
    
    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          toString()
    *   Description     Overriden toString() method to display a City object 
    *   @author         <i>Abylay Dospayev</i>
    *   @return         City object String
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    @Override 
    public String toString()
    {
        return "City Name: " + name + "\nPopulation: " + population +
                "\nMedian income per household: " + median + 
                "\nPercent of local population: " + local +
                "\nPercent of advanced degree: " + degree; 
    }
    
    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          equals()
    *   Description     Own method to check if one City object equals to another     
    *   @author         <i>Abylay Dospayev</i>
    *   @parem          city City
    *   @return         true or false boolean
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    @Override 
    public boolean equals(Object obj)
    {
        City city = new City();
        if (obj instanceof City)
        {
            city = (City) obj;
            if (this.getName().equalsIgnoreCase(city.getName())&&
                    (closeEnough(this.getPopulation(), city.getPopulation()))//&&
                    //(closeEnough(this.getMedian(), city.getMedian())) &&
                    //(closeEnough(this.getLocal(), city.getLocal())) &&
                    //(closeEnough(this.getDegree(), city.getDegree()))
                )
                return true;
            else
                return false;
        }
        else 
            return false;   //not the same class
    
    }   
            
    /**∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼
    * <pre>
    *   Method          closeEnough();
    *   Description     Method to check if two floating numbers are within 
    *                   Epsilon of each other. Used of comparison of floating
    *   @author         <i>Abylay Dospayev</i>
    *   @parem          x float
    *   @parem          x float
    *   @return         true or false boolean
    *   Date            9/23/2022
    * </pre>
    ∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼∼*/
    private boolean closeEnough(float x, float y)
    {
        final double EPSILON;
        EPSILON = 1E-9 ;
        return Math.abs(x-y) < EPSILON;
    }
}